using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GamePlay : MonoBehaviour

{
    public void Scene4()
    {
        SceneManager.LoadScene("Scene4");
        Cursor.lockState = CursorLockMode.Locked;
    }


}
